from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone


class Building(models.Model):
    name = models.CharField(max_length=100, unique=True)
    block_code = models.CharField(max_length=10, unique=True)
    total_floors = models.PositiveIntegerField()

    def clean(self):
        if self.total_floors <= 0:
            raise ValidationError("Total floors must be greater than zero.")

    def __str__(self):
        return self.name


class Room(models.Model):
    room_number = models.CharField(max_length=20)
    floor_number = models.PositiveIntegerField()
    building = models.ForeignKey(Building, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('room_number', 'building')

    def clean(self):
        if self.floor_number > self.building.total_floors:
            raise ValidationError("Floor number cannot exceed building total floors.")

    def __str__(self):
        return f"{self.room_number} - {self.building.name}"


class Asset(models.Model):

    ASSET_TYPES = [
        ('Computer', 'Computer'),
        ('Projector', 'Projector'),
        ('AC', 'AC'),
        ('Lab Equipment', 'Lab Equipment'),
    ]

    asset_name = models.CharField(max_length=100)
    asset_type = models.CharField(max_length=20, choices=ASSET_TYPES)
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    purchase_date = models.DateField()
    operational_status = models.BooleanField(default=True)

    def clean(self):
        if self.purchase_date > timezone.now().date():
            raise ValidationError("Purchase date cannot be in the future.")

    def __str__(self):
        return self.asset_name


class AssetDetail(models.Model):
    asset = models.OneToOneField(Asset, on_delete=models.CASCADE)
    vendor_name = models.CharField(max_length=100)
    warranty_years = models.PositiveIntegerField()

    def __str__(self):
        return f"Details of {self.asset.asset_name}"
