from django.contrib import admin
from .models import Building, Room, Asset, AssetDetail


admin.site.register(Building)
admin.site.register(Room)


@admin.register(Asset)
class AssetAdmin(admin.ModelAdmin):
    list_display = ('asset_name', 'asset_type', 'room', 'operational_status')
    search_fields = ('asset_name', 'room__room_number')


admin.site.register(AssetDetail)
