from django.db import models
from assets.models import Asset


class MaintenanceRequest(models.Model):

    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('In Progress', 'In Progress'),
        ('Resolved', 'Resolved'),
    ]

    PRIORITY_CHOICES = [
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High'),
    ]

    asset = models.ForeignKey(Asset, on_delete=models.CASCADE)
    issue_description = models.TextField()
    reported_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES)

    def __str__(self):
        return f"{self.asset.asset_name} - {self.status}"
