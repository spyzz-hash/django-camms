from django.contrib import admin
from .models import MaintenanceRequest


@admin.register(MaintenanceRequest)
class MaintenanceAdmin(admin.ModelAdmin):
    list_display = ('asset', 'status', 'priority', 'reported_date')
    list_filter = ('status', 'priority')
    search_fields = ('asset__asset_name', 'asset__room__room_number')
